#!/bin/sh
/Volumes/Data/Courses/Tools/makePost/Handouts/makeArchive.sh Choice MathFacts MathFactsList
/Volumes/Data/Courses/Tools/makePost/Handouts/makeArchive.sh Choice MathFacts Aggregation
/Volumes/Data/Courses/Tools/makePost/Handouts/makeArchive.sh Choice Equiprobable-Returns Aggregation
